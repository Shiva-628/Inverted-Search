// NAME:SHIVA K V 
//PROJECT:INVERTED_SEARCH
//DATE:10/03/24

#include "inverted.h"  


#define SUCCESS 0
#define FAILURE -1

int save_data_base(arr_db *arr) {     
    char file_name[MAX_NAME_LENGTH]; 
    printf("Enter the file name: ");     
    scanf("%99s", file_name); // Limit input to prevent overflow          

    FILE *fptr = fopen(file_name, "w");     
    if (fptr == NULL) {         
        printf("Error: Could not open file %s for writing.\n", file_name);         
        return FAILURE; // Indicate failure if file cannot be opened     
    }      

    for (int i = 0; i < 26; i++) { // Assuming 26 for 'a' to 'z'         
        if (arr[i].m_link != NULL) {             
            if (write_data_base(arr[i].m_link, fptr) == FAILURE) { // Corrected dereference                 
                fclose(fptr); // Close the file before returning                 
                return FAILURE; // Return failure if writing fails             
            }         
        }     
    }      

    fclose(fptr); // Close the file after writing     
    printf("Database is saved successfully.\n");     
    return SUCCESS; // Indicate success 
}  

int write_data_base(main_node *head, FILE *databasefile) {     
    while (head != NULL) {         
        int index = tolower(head->word[0]) - 'a'; // Assuming 'a' is index 0          
        fprintf(databasefile, "#:%d\n :%s:%d:", 
                index, head->word, head->file_count); 
        
        sub_node *temp = head->slink; // Get the sub list for the current word         
        while (temp != NULL) {             
            fprintf(databasefile, "FILE:%s:%d:#\n", 
                    temp->file_name, temp->word_count);             
            // Debugging print
            /*printf("Debug: Writing to file - %s with count %d\n", 
                   temp->file_name, temp->word_count);*/
            temp = temp->sub_link; // Move to the next sub_node             
            if (temp != NULL) {                 
                fprintf(databasefile, ",");             
            }         
        }         
        fprintf(databasefile, "\n"); // End of entry for the current word          
        head = head->mlink; // Move to the next main_node     
    }     
    return SUCCESS; 
} 