// NAME:SHIVA K V 
//PROJECT:INVERTED_SEARCH
//DATE:10/03/24

#include "inverted.h"

int search_data_base(main_node *node, char *word) 
{
    // Check if the head is NULL
    if (node == NULL) 
    {
        printf("Search is not possible; the list is empty.\n");
        return FAILURE; // Indicate failure
    }

    // Traverse through the linked list of main_node
    main_node *current = node; // Use a temporary pointer for traversal
    while (current)
     {
        // Compare each search word with the word in the list
        if (strcmp(current->word, word) == 0) 
        {
            printf("Word '%s' is present in %d file/s:\n", word, current->file_count);
            
            sub_node *temp = current->slink; // Access the sub list for the current word
            while (temp) {
                printf("In file: %s, %d time(s)\n", temp->file_name, temp->word_count);
                temp = temp->sub_link; // Move to the next sub_node
            }
            return SUCCESS; 
        }
        current = current->mlink; // Move to the next main_node
    }

    printf("Search word '%s' is not present in the list.\n", word);
    return FAILURE; // Indicate word not found
}
