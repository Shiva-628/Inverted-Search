// NAME:SHIVA K V 
//PROJECT:INVERTED_SEARCH
//DATE:10/03/24
#include"inverted.h"

int create_database(file_s *head, arr_db *arr) 
{
    char word[MAX_WORD_LENGTH];

    while (head != NULL) {
        FILE *fptr = fopen(head->filename, "r");
        if (fptr == NULL) {
            printf("Error: Unable to open file %s\n", head->filename);
            return FAILURE;
        }

        while (fscanf(fptr, "%s", word) != EOF) 
        {
            int key = tolower(word[0]) - 'a';
            if (key < 0 || key > 25) 
            {
                key = 26; // Handle non-alphabet characters
            }

            main_node *node = arr[key].m_link;
            while (node != NULL) 
            {
                if (strcmp(node->word, word) == 0) 
                {
                    // Word found, check for file entry
                    sub_node *sub_node_temp = node->slink;
                    int flag = 0;
                    while (sub_node_temp != NULL) 
                    {
                        if (strcmp(sub_node_temp->file_name, head->filename) == 0) {
                            // If the file already exists, increment the word count
                            sub_node_temp->word_count++;
                            flag = 1;
                            break;
                        }
                        sub_node_temp = sub_node_temp->sub_link;
                    }

                    // If the file was not found, add it
                    if (!flag) {
                        sub_node *new_sub_node = malloc(sizeof(sub_node));
                        if (new_sub_node == NULL)
                         {
                            printf("Error: Memory allocation failed\n");
                            fclose(fptr);
                            return FAILURE;
                        }
                        strcpy(new_sub_node->file_name, head->filename);
                        new_sub_node->word_count = 1; // Initial count set to 1
                        new_sub_node->sub_link = node->slink; // Insert at the beginning
                        node->slink = new_sub_node; // Update the link
                        node->file_count++; // Increment file count
                    }
                    break; // Break since we've processed this word
                }
                node = node->mlink; // Move to next main_node
            }

            // If the word was not found, create a new main_node
            if (node == NULL) 
            {
                main_node *new_node = malloc(sizeof(main_node));
                if (new_node == NULL) 
                {
                    printf("Error: Memory allocation failed\n");
                    fclose(fptr);
                    return FAILURE;
                }
                strcpy(new_node->word, word);
                new_node->file_count = 1; // Set initial file count to 1

                // Create the sub_node for the current file
                sub_node *new = malloc(sizeof(sub_node));
                if (new == NULL) 
                {
                    printf("Error: Memory allocation failed\n");
                    free(new_node);
                    fclose(fptr);
                    return FAILURE;
                }
                strcpy(new->file_name, head->filename);
                new->word_count = 1; // Set initial count to 1
                new->sub_link = NULL; // No further sub_nodes yet
                new_node->slink = new;

                // Link the new main_node to the correct place in the array
                if (arr[key].m_link == NULL)
                 {
                    arr[key].m_link = new_node; // First node for this key
                } else {
                    main_node *prev = arr[key].m_link;
                    while (prev->mlink != NULL)
                     {
                        prev = prev->mlink; // Traverse to the end
                    }
                    prev->mlink = new_node; // Append the new node
                }
            }
        }
        fclose(fptr);
        head = head->link; // Move to the next file
    }
    return SUCCESS; // Success
}