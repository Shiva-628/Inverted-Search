// NAME:SHIVA K V 
//PROJECT:INVERTED_SEARCH
//DATE:10/03/24

#include "inverted.h"

int update_data_base(arr_db arr[], file_s **head) 
{
    char file_name[MAX_NAME_LENGTH];
    printf("Enter the file name to add:\n");

    // Clear any previous newline or leftover input
    while (getchar() != '\n');

    // Use fgets to read the input
    fgets(file_name, sizeof(file_name), stdin);
    file_name[strcspn(file_name, "\n")] = '\0'; // Remove newline if present

    int empty = is_file_empty(file_name);

    // Check if the file exists and is not empty
    if (empty == FILE_NOT_FOUND) {
        printf("FILE: %s is not available\n", file_name);
        return FAILURE;
    } else if (empty == FILE_EMPTY) {
        printf("FILE: %s is empty\n", file_name);
        return FAILURE;
    }

    // Check if the file is already in the linked list
    file_s *current = *head;
    while (current) {
        if (strcmp(current->filename, file_name) == 0) {
            printf("Duplicate file: %s is already in the database. No action taken.\n", file_name);
            return SUCCESS; // No need to add or update
        }
        current = current->link; // Move to the next node
    }

    // If it's not a duplicate, create the list
    int result = create_list(head, file_name); // Pass head by reference

    // Handle the result of create_list
    if (result == SUCCESS) {
        printf("Successfully added file: %s to the linked list.\n", file_name);
    } else if (result == REPEATED) {
        printf("Failed: %s is a duplicate. Not adding to the linked list.\n", file_name);
    } else {
        printf("FAILURE\n");
        return FAILURE;
    }

    // If you want to update the database with the new file
    if (create_database(*head, arr) == FAILURE) {
        printf("Error updating database with file: %s\n", file_name);
        return FAILURE;
    }

    return SUCCESS; // Return success at the end
}
