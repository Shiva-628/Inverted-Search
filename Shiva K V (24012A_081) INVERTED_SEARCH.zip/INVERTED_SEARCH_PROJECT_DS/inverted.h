// NAME:SHIVA K V 
//PROJECT:INVERTED_SEARCH
//DATE:10/03/24

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#define MAX_WORD_LENGTH 20
#define MAX_NAME_LENGTH 100
#define SUCCESS 0
#define FAILURE -1
#define REPEATED 1
#define FILE_NOT_FOUND -2
#define FILE_EMPTY -3
#define FILE_NOT_EMPTY 0

typedef struct sub_node 
{
    char file_name[MAX_NAME_LENGTH];
    int word_count;
    struct sub_node *sub_link;
} sub_node;

typedef struct main_node
 {
    char word[MAX_WORD_LENGTH];
    int file_count;
    sub_node *slink; // Link to sub_node list
    struct main_node *mlink; // Link to the next main_node
} main_node;

typedef struct arr_db 
{
    main_node *m_link; // Link to the main_node list
} arr_db;

typedef struct file_s 
{
    char *filename;
    struct file_s *link; // Link to the next file_s
} file_s;



// Function prototypes
int has_txt_extension(const char *filename);
int create_database(file_s *head, arr_db *arr);
int display_database(arr_db *arr);
int search_data_base(main_node *node, char *word);
int save_data_base(arr_db *arr);

int update_data_base(arr_db arr[], file_s **head);
void read_and_validate(file_s **head, char *argv[], int argc);
int is_file_empty(char *filename);
int create_list(file_s **head, char *filename);
int write_data_base(main_node *head, FILE *databasefile);