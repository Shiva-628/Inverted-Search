// NAME:SHIVA K V 
//PROJECT:INVERTED_SEARCH
//DATE:10/03/24

#include"inverted.h"

int flag_is_database_created = 0;
int flag_is_database_updated = 0; // Flag for update status

int main(int argc, char *argv[]) 
{
    int choice;
    file_s *head = NULL;
    arr_db arr[27] = {0}; // 26 for a-z and 1 for non-alphabet

    // Validate command line arguments
    if (argc <= 1) 
    {
        printf("Enter a valid number of Arguments\n ./a.out file.txt file1.txt file2.txt..\n");
        return FAILURE;
    }

    // Check for .txt extension in command line arguments
    for (int i = 1; i < argc; i++) {
        if (!has_txt_extension(argv[i])) 
        {
            printf("Error: %s is not a .txt file and will be ignored.\n", argv[i]);
            continue; // Skip invalid files
        }
    }

    read_and_validate(&head, argv, argc); // Pass head by reference

    if (head == NULL) {
        printf("No valid .txt files are available in the linked list.\n");
        return FAILURE; // Exit if no files
    }

    do {
        printf("Select the choice among the following:\n");
        printf("1) Create list.\n2) Display.\n3) Search.\n4) Save\n5) Update\n6) Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                if (!flag_is_database_created) 
                { // Check if database already created
                    if (create_database(head, arr) == SUCCESS) 
                    {
                        printf("Successfully created database\n");
                        flag_is_database_created = 1; // Set the global flag to true
                    } else {
                        printf("Failed to create database\n");
                    }
                } else {
                    printf("Database has already been created. Cannot create it again.\n");
                }
                break;
            case 2:
                if (display_database(arr) == SUCCESS)
                 {
                    printf("Successfully displayed database\n");
                } else {
                    printf("Failed to display database\n");
                }
                break;
            case 3: 
            {
                char word[MAX_WORD_LENGTH];
                printf("Enter the word to search: ");
                scanf("%s", word);
                int index = tolower(word[0]) - 'a';
                if (index >= 0 && index < 26)
                 {
                    if (search_data_base(arr[index].m_link, word) == SUCCESS) {
                        printf("Successfully found the word in the database.\n");
                    } else {
                        printf("Failed to find the word in the database.\n");
                    }
                } else {
                    printf("Invalid index calculated for the word.\n");
                }
                break;
            }
            case 4:
                if (save_data_base(arr) == SUCCESS) 
                {
                    printf("Successfully saved the database\n");
                } else 
                {
                    printf("Failed to save the database\n");
                }
                break;
            case 5:
                if (!flag_is_database_updated) 
                { // Check if database already updated
                    if (update_data_base(arr, &head) == SUCCESS) 
                    {
                        printf("Successfully updated database\n");
                        flag_is_database_updated = 1; // Set the global flag to true
                    } else {
                        printf("Failed to update database\n");
                    }
                } else 
                {
                    printf("Database has already been updated. Cannot update again.\n");
                }
                break;
            case 6:
                printf("Exiting program...\n");
                exit(0); // Exit the program
            default:
                printf("Invalid choice\n");
                continue; // Skip the continuation prompt if invalid
        }

        // Prompt to continue or exit
        char choose;
        printf("Do you want to continue (y/n)? ");
        scanf(" %c", &choose); // The space before %c consumes any leftover newline
        if (choose != 'y' && choose != 'Y') 
        {
            printf("Exiting program...\n");
            break; // Exit the loop if the input is not 'y' or 'Y'
        }

    } while (1); // Continue indefinitely until the user decides to exit

    return 0;
}

// Function to check if a file has a .txt extension
int has_txt_extension(const char *filename) 
{
    // Check if the filename is long enough
    if (strlen(filename) < 4) return 0;
    return strcmp(filename + strlen(filename) - 4, ".txt") == 0;
}

void read_and_validate(file_s **head, char *argv[], int argc) 
{
    for (int i = 1; i < argc; i++) 
    {
        int empty = is_file_empty(argv[i]);

        if (empty == FILE_NOT_FOUND) {
            printf("FILE: %s is not available\n", argv[i]);
            continue;
        } else if (empty == FILE_EMPTY)
         {
            printf("FILE: %s is empty\n", argv[i]);
            continue;
        }

        int result = create_list(head, argv[i]);

        if (result == SUCCESS) 
        {
            printf("Successfully added file: %s to the linked list.\n", argv[i]);
        } else if (result == REPEATED) 
        {
            printf("Failed: %s is a duplicate. Not adding to the linked list.\n", argv[i]);
        } else {
            printf("FAILURE\n");
        }
    }
}

int is_file_empty(char *filename) 
{
    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL) 
    {
        if (errno == ENOENT) {
            return FILE_NOT_FOUND;
        }
        perror("Error opening file");
        return FAILURE;
    }

    fseek(fptr, 0, SEEK_END);
    if (ftell(fptr) == 0) 
    {
        fclose(fptr);
        return FILE_EMPTY;
    }

    fclose(fptr);
    return FILE_NOT_EMPTY;
}

int create_list(file_s **head, char *filename)
 {
    file_s *current = *head;

    // Check for duplicates
    while (current != NULL) 
    {
        if (strcmp(current->filename, filename) == 0) 
        {
            return REPEATED;
        }
        current = current->link;
    }

    // Create a new node
    file_s *new = malloc(sizeof(file_s));
    if (new == NULL) 
    {
        perror("Failed to allocate memory");
        return FAILURE;
    }

    new->filename = strdup(filename);
    if (new->filename == NULL) 
    {
        perror("Failed to duplicate string");
        free(new);
        return FAILURE;
    }

    new->link = *head; // Insert at the beginning
    *head = new; 

    return SUCCESS; 
}