// NAME:SHIVA K V 
//PROJECT:INVERTED_SEARCH
//DATE:10/03/24

#include"inverted.h"

int display_database(arr_db *arr) 
{
    printf("%s\t%s\t  %s\t%s\t%s\n", "Index", "Word", "File Count", "Files Name", "Word Count");
    printf("----------------------------------------------------------\n");
    for (int key = 0; key < 27; key++)
     {
        main_node *temp = arr[key].m_link;
        while (temp != NULL) {
            printf("[%d]\t[ %s ]\t\t%d file/s:\t", key, temp->word, temp->file_count);
            sub_node *sub_temp = temp->slink;

            // Print sub-nodes (files and word counts)
            if (sub_temp == NULL) 
            {
                printf("[No files]\n");
            } else 
            {
                while (sub_temp != NULL) 
                {
                    printf("File:%s\t(%d) ", sub_temp->file_name, sub_temp->word_count);
                    sub_temp = sub_temp->sub_link;
                }
                printf("\n");
            }
            temp = temp->mlink;
        }
    }
    return 0;
}